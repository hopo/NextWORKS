// [과제 1] 자바에서 제공하는 기본데이터타입을 이용하여 개인 정보를 출력하는 프로그램을 작성하시오.
public class Exam01 {
	public static void main(String[] args) {
		
		byte groupCode = 42;
		char bloodType = 'B';
		int birthYear = 1977;
		short birthMonth = 7;
		double height = 169.5;
		float weight = 53.4f;
		boolean married = true;
		long lng = 999000;
		
		System.out.println("그룹: " + groupCode);
		System.out.println("혈액형: " + bloodType);
		System.out.println("생년:" + birthYear);
		System.out.println("생월: " + birthMonth);
		System.out.println("신장: " + height);
		System.out.println("체중: " + weight);
		System.out.println("결혼: " + married);
		System.out.println("잔고: " + lng);
		
	}

}
